package main

import "6_gopro/server"

func main() {

	server.RunServer()

}
